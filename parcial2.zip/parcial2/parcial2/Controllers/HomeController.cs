﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using parcial2.Models;
using System.Diagnostics;

namespace parcial2.Controllers
{
    public class HomeController : Controller
    {
        private readonly HttpClient _httpClient;

        public HomeController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("2Caso -Marvin - William");

        }

        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetAsync("/api/v1/Producto");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<RespuestaApi>(json);

                // Verificar si la propiedad "Datos" dentro de "RespuestaApi" no es nula
                if (data != null && data.Datos != null)
                {
                    return View(data);
                }
            }

            // Inicializar el objeto "Model" si es nulo
            var emptyData = new RespuestaApi { Datos = new List<Productos>() };
            return View(emptyData);
        }

    }
}