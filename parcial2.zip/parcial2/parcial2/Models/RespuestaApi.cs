﻿namespace parcial2.Models
{
    public class RespuestaApi
    {
        public int NumeroPagina { get; set; }
        public int TamanioPagina { get; set; }
        public bool Confirmar { get; set; }
        public string Mensaje { get; set; }
        public object Errors { get; set; }

        
        public List<Productos> Datos { get; set; }
    }
    public class Productos
    {

        public int Id { get; set; }
        public string producto { get; set; }

        public DateTime fechaRegistro { get; set; }

        public double precioCompra { get; set; }

        public double PrecioVenta { get; set; }

        public string Existencias { get; set; }


    }
}
