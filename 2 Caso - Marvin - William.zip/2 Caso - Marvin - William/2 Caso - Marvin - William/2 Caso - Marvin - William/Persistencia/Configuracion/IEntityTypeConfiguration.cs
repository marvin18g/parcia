﻿namespace Persistencia.Configuracion
{
    public interface IEntityTypeConfiguration<T1, T2>
    {
    }
}