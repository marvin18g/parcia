﻿using Aplicacion.Parametros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.Feautres.Productos.Consultas.ObtenerTodosProductos
{
    public class ObtenerTodoProductosParametros : RespuestaParametros
    {
        public string? producto { get; set; }
    }
}
