﻿using Aplicacion.DTOs;
using Aplicacion.Feautres.Productos.Comandos.CrearProducto;
using AutoMapper;
using Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.Mappings
{
    public class PerfilMapeo : Profile
    {
        public PerfilMapeo()
        {
            #region Commands
            CreateMap<CrearProducto, Producto>();
            #endregion

            #region DTOs
            CreateMap<Producto, ProductoDto>();
            #endregion
        }
    }
}
