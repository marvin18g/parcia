﻿namespace vista_cliente.Models
{
    public class RespuestaApi
    {
        public int NumeroPagina { get; set; }
        public int TamanioPagina { get; set; }
        public bool Confirmar { get; set; }
        public string Mensaje { get; set; }
        public object Errors { get; set; }

        public int Total { get; set; }
        public List<Libro> Datos { get; set; }

    }
    public class Libro 
    {
        public int Id { get; set; }
        public string TituloLibro { get; set; }
        public int CantidadPaginas { get; set; }
        public string Editorial { get; set; }
        public int cantidad { get; set; }

    }
}


